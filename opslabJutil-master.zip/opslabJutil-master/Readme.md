#opslabJutil
---
封装了一些常用Java操作方法,便于重复开发利用.另外希望身为Java牛牛的你们一起测试和完善 一起封装和完成常用的Java代码。
节约撸码时间以方便有更多的时间去把妹子～扫描可关注我(微信公众号),当然也可以请我喝杯咖啡


<div align=center> 
<img src="https://0opslab.github.io/img/wpwx.png" alt="关注我">
<img src="https://0opslab.github.io/img/wxpay.png" alt="请问喝杯咖啡"/>
</div>

---
#开发环境
    Win7x64 && ubuntu14 && MacOS
    JDK1.8
    IDEA14


#usage
```xml
<dependency>
    <groupId>com.0opslab</groupId>
    <artifactId>opslabJutil</artifactId>
    <version>1.0.8</version>
</dependency>

<!--后续版本-->
<!-- 由于上传maven中心比较慢，相当浪费时间，因此后续版本不在上传的maven中心，可以像如下方式使用 -->
<!-- Since uploading the maven center is slow and time consuming, the subsequent 
       version is not in the uploaded maven center and can be used as follows -->
<dependency>
    <groupId>com.0opslab</groupId>
    <artifactId>opslabJutil</artifactId>
    <version>3.0.0</version>
    <scope>system</scope>
    <systemPath>${project.basedir}/libs/opslabJutil-3.0.0.jar</systemPath>
</dependency>
```

## 在线api
[opslabJutil2.x API Doc](https://0opslab.github.io/opslabJutil/opslabJutil2.0.html)<br>

[opslabJutil3.0.0 API Doc](https://0opslab.github.io/opslabJutil/opslabJutil3.0.0.html)<br>



