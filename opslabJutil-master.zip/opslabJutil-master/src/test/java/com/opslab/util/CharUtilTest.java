package com.opslab.util;


import org.junit.Test;

public class CharUtilTest {

    @Test
    public void testToChar() throws Exception {

    }

    @Test
    public void testToSimpleByteArray() throws Exception {

    }

    @Test
    public void testToSimpleByteArray1() throws Exception {

    }

    @Test
    public void testToSimpleCharArray() throws Exception {

    }

    @Test
    public void testToAscii() throws Exception {

    }

    @Test
    public void testToAsciiByteArray() throws Exception {

    }

    @Test
    public void testToAsciiByteArray1() throws Exception {

    }

    @Test
    public void testToRawByteArray() throws Exception {

    }

    @Test
    public void testToRawCharArray() throws Exception {

    }

    @Test
    public void testToByteArray() throws Exception {

    }

    @Test
    public void testToByteArray1() throws Exception {

    }

    @Test
    public void testToCharArray() throws Exception {

    }

    @Test
    public void testToCharArray1() throws Exception {

    }

    @Test
    public void testEqualsOne() throws Exception {

    }

    @Test
    public void testFindFirstEqual() throws Exception {

    }

    @Test
    public void testFindFirstEqual1() throws Exception {

    }

    @Test
    public void testFindFirstDiff() throws Exception {

    }

    @Test
    public void testFindFirstDiff1() throws Exception {

    }

    @Test
    public void testIsWhitespace() throws Exception {

    }

    @Test
    public void testIsLowercaseAlpha() throws Exception {

    }

    @Test
    public void testIsUppercaseAlpha() throws Exception {

    }

    @Test
    public void testIsAlphaOrDigit() throws Exception {

    }

    @Test
    public void testIsWordChar() throws Exception {

    }

    @Test
    public void testIsPropertyNameChar() throws Exception {

    }

    @Test
    public void testIsAlpha() throws Exception {

    }

    @Test
    public void testIsDigit() throws Exception {

    }

    @Test
    public void testIsHexDigit() throws Exception {

    }

    @Test
    public void testIsGenericDelimiter() throws Exception {

    }

    @Test
    public void testIsSubDelimiter() throws Exception {

    }

    @Test
    public void testIsReserved() throws Exception {

    }

    @Test
    public void testIsUnreserved() throws Exception {

    }

    @Test
    public void testIsPchar() throws Exception {

    }

    @Test
    public void testToUpperAscii() throws Exception {

    }

    @Test
    public void testToLowerAscii() throws Exception {

    }


}